import { useEffect, useRef, useState, useCallback } from 'react'
import * as XLSX from 'xlsx'
import jsQR from 'jsqr'
import Tesseract from 'tesseract.js'

// ══════════════════════════════════════════════
// Types
// ══════════════════════════════════════════════
interface StudentRow {
  rowIndex: number // 1-based row in sheet (header=0)
  studentId: string
  studentName: string
  className: string
  secretCode: string
  grades: Record<string, number | string | null>
}

interface ExcelData {
  fileName: string
  subjects: string[] // length 1..15, columns E..S
  students: StudentRow[]
}

interface ScanState {
  phase: 'idle' | 'scanning' | 'confirm'
  subjectCode: string
  qrValue: string
  gradeRaw: string
  studentRow: StudentRow | null
}

// ══════════════════════════════════════════════
// Helpers
// ══════════════════════════════════════════════
const COLS = ['E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S']

function arabicToWestern(str: string): string {
  return str
    .replace(/[٠١٢٣٤٥٦٧٨٩]/g, d => String(d.charCodeAt(0) - 1632))
    .replace(/[۰۱۲۳۴۵۶۷۸۹]/g, d => String(d.charCodeAt(0) - 1776))
}

function extractNumber(raw: string): string {
  const cleaned = arabicToWestern(raw).replace(/[^0-9.]/g, '')
  return cleaned || ''
}

// ══════════════════════════════════════════════
// Main Component
// ══════════════════════════════════════════════
export default function Home() {
  // ── Theme ──
  const [darkMode, setDarkMode] = useState(true)

  // ── Excel ──
  const [excelData, setExcelData] = useState<ExcelData | null>(null)
  const [selectedSubjectIdx, setSelectedSubjectIdx] = useState<number>(-1)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const workbookRef = useRef<XLSX.WorkBook | null>(null)
  const fileNameRef = useRef<string>('')

  // ── Scan ──
  const [cameraActive, setCameraActive] = useState(false)
  const [flashOn, setFlashOn] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const scanIntervalRef = useRef<number | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const trackRef = useRef<MediaStreamTrack | null>(null)

  // ── State ──
  const [scanState, setScanState] = useState<ScanState>({
    phase: 'idle',
    subjectCode: '',
    qrValue: '',
    gradeRaw: '',
    studentRow: null,
  })
  const [secretCodeDisplay, setSecretCodeDisplay] = useState('')
  const [gradeInput, setGradeInput] = useState('')
  const [statusMsg, setStatusMsg] = useState('')
  const [statusType, setStatusType] = useState<'info' | 'success' | 'error' | 'warn'>('info')

  // ── OCR ──
  const [ocrLoading, setOcrLoading] = useState(false)

  // ── Stats ──
  const [totalStudents, setTotalStudents] = useState(0)
  const [scannedStudents, setScannedStudents] = useState(0)
  const [showStats, setShowStats] = useState(false)

  // ── Scan phase tracker ──
  const scanPhaseRef = useRef<'subject_code' | 'qr' | 'grade'>('subject_code')
  const subjectCodeFoundRef = useRef('')
  const qrFoundRef = useRef('')

  // ══════════════════════════════════════════════
  // Colours / Theme
  // ══════════════════════════════════════════════
  const colors = darkMode
    ? {
        bg: '#1a0a2e',
        card: '#2d1b4e',
        input: '#0d0020',
        border: '#7b2fbe',
        text: '#e8d5ff',
        subtext: '#b39ddb',
        btnPrimary: '#4caf50',
        btnPrimaryHover: '#43a047',
        btnGold: '#ffc107',
        btnGoldHover: '#ffb300',
        header: '#9c27b0',
      }
    : {
        bg: '#7b1fa2',
        card: '#9c27b0',
        input: '#1a0030',
        border: '#ce93d8',
        text: '#fff',
        subtext: '#f3e5f5',
        btnPrimary: '#4caf50',
        btnPrimaryHover: '#43a047',
        btnGold: '#ffc107',
        btnGoldHover: '#ffb300',
        header: '#6a1b9a',
      }

  // ══════════════════════════════════════════════
  // Excel loading
  // ══════════════════════════════════════════════
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target!.result as ArrayBuffer)
        const wb = XLSX.read(data, { type: 'array' })
        workbookRef.current = wb
        fileNameRef.current = file.name

        const ws = wb.Sheets[wb.SheetNames[0]]
        const rows: unknown[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' }) as unknown[][]

        if (rows.length < 1) {
          showStatus('الملف فارغ!', 'error')
          return
        }

        const headerRow = rows[0] as unknown[]
        // Extract subject names from columns E(index4) to S(index18)
        const subjects: string[] = []
        for (let i = 4; i <= 18; i++) {
          const val = headerRow[i]
          if (val !== undefined && val !== null && String(val).trim() !== '') {
            subjects.push(String(val).trim())
          }
        }

        // Build student list from row 2 onwards
        const students: StudentRow[] = []
        for (let r = 1; r < rows.length; r++) {
          const row = rows[r] as unknown[]
          if (!row || row.every(c => c === '' || c === null || c === undefined)) continue
          const grades: Record<string, number | string | null> = {}
          subjects.forEach((subj, si) => {
            const colIdx = 4 + si
            grades[subj] = row[colIdx] !== undefined && row[colIdx] !== '' ? row[colIdx] as number | string | null : null
          })
          students.push({
            rowIndex: r,
            studentId: String(row[0] ?? ''),
            studentName: String(row[1] ?? ''),
            className: String(row[2] ?? ''),
            secretCode: String(row[3] ?? ''),
            grades,
          })
        }

        setExcelData({ fileName: file.name, subjects, students })
        setSelectedSubjectIdx(-1)
        setTotalStudents(students.length)
        // Count already graded for last selected subject (reset for now)
        setScannedStudents(0)
        showStatus(`✅ تم تحميل الملف: ${file.name} — ${students.length} طالب، ${subjects.length} مادة`, 'success')
      } catch {
        showStatus('❌ فشل في قراءة الملف. تأكد أنه ملف Excel صحيح.', 'error')
      }
    }
    reader.readAsArrayBuffer(file)
  }, [])

  // ══════════════════════════════════════════════
  // Update scanned count when subject changes
  // ══════════════════════════════════════════════
  useEffect(() => {
    if (!excelData || selectedSubjectIdx < 0) {
      setScannedStudents(0)
      return
    }
    const subj = excelData.subjects[selectedSubjectIdx]
    const count = excelData.students.filter(s => s.grades[subj] !== null && s.grades[subj] !== '').length
    setScannedStudents(count)
  }, [selectedSubjectIdx, excelData])

  // ══════════════════════════════════════════════
  // Status helper
  // ══════════════════════════════════════════════
  const showStatus = (msg: string, type: 'info' | 'success' | 'error' | 'warn') => {
    setStatusMsg(msg)
    setStatusType(type)
  }

  // ══════════════════════════════════════════════
  // Camera & Scanning
  // ══════════════════════════════════════════════
  const stopCamera = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
      scanIntervalRef.current = null
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop())
      streamRef.current = null
    }
    trackRef.current = null
    setCameraActive(false)
  }, [])

  const startCamera = useCallback(async () => {
    if (!excelData || selectedSubjectIdx < 0) {
      showStatus('⚠️ الرجاء اختيار ملف الأكسيل والمادة أولاً', 'warn')
      return
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      })
      streamRef.current = stream
      trackRef.current = stream.getVideoTracks()[0]
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setCameraActive(true)
      scanPhaseRef.current = 'subject_code'
      subjectCodeFoundRef.current = ''
      qrFoundRef.current = ''
      showStatus('📷 الكاميرا تعمل — قم بتوجيه الكاميرا نحو الورقة', 'info')
      startScanLoop()
    } catch {
      showStatus('❌ تعذّر الوصول إلى الكاميرا. تحقق من الأذونات.', 'error')
    }
  }, [excelData, selectedSubjectIdx])

  const startScanLoop = useCallback(() => {
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current)
    scanIntervalRef.current = window.setInterval(() => {
      processFrame()
    }, 300)
  }, [])

  const processFrame = useCallback(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas || video.readyState < 2) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    ctx.drawImage(video, 0, 0)
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)

    // Try QR detection in current frame
    const qrResult = jsQR(imageData.data, imageData.width, imageData.height)

    if (scanPhaseRef.current === 'subject_code') {
      // We look for a printed number (subject code) via QR or text
      // For simplicity: first QR found is assumed to encode the subject code
      // OR if there is a printed barcode/number – we detect a QR that encodes the code
      if (qrResult) {
        const val = qrResult.data.trim()
        // Check if this QR encodes a subject code (pure number 1-15)
        const num = parseInt(val, 10)
        if (!isNaN(num) && num >= 1 && num <= 15 && val === String(num)) {
          subjectCodeFoundRef.current = val
          scanPhaseRef.current = 'qr'
          showStatus(`🔍 كود المادة: ${val} — الآن يتم البحث عن رمز QR الخاص بالطالب`, 'info')
        } else {
          // This QR might be a student QR — treat subject code as matched if it's not a number
          // OR show mismatch — but we need the printed number first
          // Fallback: assume subject code area is separate; try OCR
          tryOCRForSubjectCode(canvas)
        }
      } else {
        tryOCRForSubjectCode(canvas)
      }
    } else if (scanPhaseRef.current === 'qr') {
      if (qrResult) {
        const val = qrResult.data.trim()
        // Subject code QR is numeric 1-15, student QR is different
        const num = parseInt(val, 10)
        const isSubjectCode = !isNaN(num) && num >= 1 && num <= 15 && val === String(num)
        if (!isSubjectCode) {
          // This is the student QR
          qrFoundRef.current = val
          handleQRFound(val)
        }
      }
    }
  }, [excelData, selectedSubjectIdx])

  // OCR attempt for subject code (top portion of frame)
  const tryOCRForSubjectCode = useCallback(async (canvas: HTMLCanvasElement) => {
    if (ocrLoading) return
    // Crop top-third of image for OCR
    const tmpCanvas = document.createElement('canvas')
    tmpCanvas.width = canvas.width
    tmpCanvas.height = Math.floor(canvas.height / 3)
    const tmpCtx = tmpCanvas.getContext('2d')
    if (!tmpCtx) return
    tmpCtx.drawImage(canvas, 0, 0, canvas.width, tmpCanvas.height, 0, 0, tmpCanvas.width, tmpCanvas.height)
    setOcrLoading(true)
    try {
      const result = await Tesseract.recognize(tmpCanvas, 'ara+eng', {})
      const text = arabicToWestern(result.data.text)
      const numbers = text.match(/\b([1-9]|1[0-5])\b/)
      if (numbers) {
        const code = numbers[1]
        subjectCodeFoundRef.current = code
        scanPhaseRef.current = 'qr'
        showStatus(`🔍 كود المادة المطبوع: ${code} — الآن يتم البحث عن رمز QR`, 'info')
      }
    } catch { /* ignore */ }
    setOcrLoading(false)
  }, [ocrLoading])

  const handleQRFound = useCallback((qrValue: string) => {
    if (!excelData || selectedSubjectIdx < 0) return

    // Validate subject code matches selected subject
    const selectedSubjectCode = String(selectedSubjectIdx + 1)
    if (subjectCodeFoundRef.current && subjectCodeFoundRef.current !== selectedSubjectCode) {
      stopScanLoop()
      showStatus(
        `⚠️ تنبيه: كود المادة في الورقة (${subjectCodeFoundRef.current}) لا يطابق المادة المختارة (${selectedSubjectCode}). تحقق من المادة المختارة.`,
        'warn'
      )
      setTimeout(() => {
        scanPhaseRef.current = 'subject_code'
        subjectCodeFoundRef.current = ''
        qrFoundRef.current = ''
        startScanLoop()
      }, 3000)
      return
    }

    // Find student by QR value (secret code)
    const student = excelData.students.find(s => s.secretCode === qrValue)
    if (!student) {
      stopScanLoop()
      showStatus('❌ طالب غير موجود — رمز QR غير معرّف في ملف الأكسيل', 'error')
      setTimeout(() => {
        scanPhaseRef.current = 'subject_code'
        subjectCodeFoundRef.current = ''
        qrFoundRef.current = ''
        startScanLoop()
      }, 3000)
      return
    }

    const subj = excelData.subjects[selectedSubjectIdx]
    // Check if already graded
    if (student.grades[subj] !== null && student.grades[subj] !== '') {
      stopScanLoop()
      showStatus(`⚠️ تم بالفعل إدخال درجة هذا الطالب مسبقاً (${student.grades[subj]})`, 'warn')
      setSecretCodeDisplay(student.secretCode)
      setTimeout(() => {
        scanPhaseRef.current = 'subject_code'
        subjectCodeFoundRef.current = ''
        qrFoundRef.current = ''
        setSecretCodeDisplay('')
        startScanLoop()
      }, 3000)
      return
    }

    // Found! Now try OCR for grade
    setSecretCodeDisplay(student.secretCode)
    stopScanLoop()
    showStatus('✅ تم التعرف على الطالب — جارٍ قراءة الدرجة...', 'success')
    setScanState(prev => ({ ...prev, phase: 'confirm', qrValue, studentRow: student }))

    // OCR for grade (bottom portion of frame)
    const canvas = canvasRef.current
    if (canvas) {
      performGradeOCR(canvas, student)
    }
  }, [excelData, selectedSubjectIdx])

  const performGradeOCR = useCallback(async (canvas: HTMLCanvasElement, _student: StudentRow) => {
    // Crop bottom-third
    const tmpCanvas = document.createElement('canvas')
    tmpCanvas.width = canvas.width
    tmpCanvas.height = Math.floor(canvas.height / 3)
    const tmpCtx = tmpCanvas.getContext('2d')
    if (!tmpCtx) return
    tmpCtx.drawImage(
      canvas,
      0, canvas.height - tmpCanvas.height,
      canvas.width, tmpCanvas.height,
      0, 0, tmpCanvas.width, tmpCanvas.height
    )
    setOcrLoading(true)
    try {
      const result = await Tesseract.recognize(tmpCanvas, 'ara+eng', {})
      const raw = result.data.text
      const num = extractNumber(raw)
      setGradeInput(num)
      if (num) {
        showStatus(`📝 درجة مقروءة: ${num} — يمكنك تعديلها ثم اضغط "حفظ الدرجة"`, 'info')
      } else {
        showStatus('⚠️ تعذّر قراءة الدرجة تلقائياً — الرجاء إدخالها يدوياً', 'warn')
        setGradeInput('')
      }
    } catch {
      showStatus('⚠️ خطأ في قراءة الدرجة — الرجاء الإدخال اليدوي', 'warn')
      setGradeInput('')
    }
    setOcrLoading(false)
  }, [])

  const stopScanLoop = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
      scanIntervalRef.current = null
    }
  }, [])

  // Flash toggle
  const toggleFlash = useCallback(async () => {
    if (!trackRef.current) return
    try {
      const newFlash = !flashOn
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (trackRef.current as any).applyConstraints({ advanced: [{ torch: newFlash }] })
      setFlashOn(newFlash)
    } catch {
      showStatus('⚠️ الفلاش غير مدعوم على هذا الجهاز', 'warn')
    }
  }, [flashOn])

  // ══════════════════════════════════════════════
  // Save Grade
  // ══════════════════════════════════════════════
  const saveGrade = useCallback(() => {
    if (!excelData || selectedSubjectIdx < 0 || !scanState.studentRow) return
    const gradeVal = extractNumber(gradeInput)
    if (gradeVal === '') {
      showStatus('⚠️ الرجاء إدخال الدرجة قبل الحفظ', 'warn')
      return
    }
    const grade = parseFloat(gradeVal)
    const subj = excelData.subjects[selectedSubjectIdx]
    const colIdx = 4 + selectedSubjectIdx // E=4
    const rowIdx = scanState.studentRow.rowIndex + 1 // xlsx row (1-based header)

    try {
      const wb = workbookRef.current
      if (!wb) return
      const ws = wb.Sheets[wb.SheetNames[0]]
      const cellAddress = XLSX.utils.encode_cell({ r: rowIdx, c: colIdx })
      ws[cellAddress] = { v: grade, t: 'n' }
      if (!ws['!ref']) ws['!ref'] = `A1:S${rowIdx + 1}`

      // Update local state
      setExcelData(prev => {
        if (!prev) return prev
        const updatedStudents = prev.students.map(s => {
          if (s.rowIndex === scanState.studentRow!.rowIndex) {
            return { ...s, grades: { ...s.grades, [subj]: grade } }
          }
          return s
        })
        return { ...prev, students: updatedStudents }
      })

      // Download updated file
      XLSX.writeFile(wb, fileNameRef.current || 'grades.xlsx')

      setScannedStudents(prev => prev + 1)
      showStatus(`✅ تم حفظ درجة الطالب (${scanState.studentRow.studentName}): ${grade}`, 'success')

      // Reset & restart camera
      setScanState({ phase: 'idle', subjectCode: '', qrValue: '', gradeRaw: '', studentRow: null })
      setSecretCodeDisplay('')
      setGradeInput('')
      scanPhaseRef.current = 'subject_code'
      subjectCodeFoundRef.current = ''
      qrFoundRef.current = ''

      setTimeout(() => {
        startScanLoop()
      }, 500)
    } catch {
      showStatus('❌ فشل حفظ الدرجة', 'error')
    }
  }, [excelData, selectedSubjectIdx, scanState, gradeInput])

  // ══════════════════════════════════════════════
  // Cleanup
  // ══════════════════════════════════════════════
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [stopCamera])

  // ══════════════════════════════════════════════
  // Status colour
  // ══════════════════════════════════════════════
  const statusBg = {
    info: '#1565c0',
    success: '#1b5e20',
    error: '#b71c1c',
    warn: '#e65100',
  }[statusType]

  // ══════════════════════════════════════════════
  // Render
  // ══════════════════════════════════════════════
  return (
    <div
      dir="rtl"
      style={{
        minHeight: '100vh',
        background: colors.bg,
        color: colors.text,
        fontFamily: 'Cairo, Tajawal, Arial, sans-serif',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '0 0 40px 0',
        transition: 'background 0.3s',
      }}
    >
      {/* ── Header ── */}
      <div
        style={{
          width: '100%',
          background: colors.header,
          padding: '18px 20px 10px',
          textAlign: 'center',
          boxShadow: '0 2px 8px #0006',
          position: 'relative',
        }}
      >
        <h1 style={{ margin: 0, fontSize: 24, fontWeight: 'bold', color: '#fff' }}>
          برنامج إسقاط الدرجات
        </h1>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: '#e1bee7' }}>بالأكواد</p>

        {/* Theme & Flash toggles */}
        <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', gap: 8 }}>
          <button
            onClick={() => setDarkMode(d => !d)}
            title={darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
            style={{
              background: darkMode ? '#ffd54f' : '#303f9f',
              border: 'none', borderRadius: 20, padding: '6px 12px',
              color: darkMode ? '#333' : '#fff', cursor: 'pointer', fontSize: 13,
            }}
          >
            {darkMode ? '☀️ نهاري' : '🌙 ليلي'}
          </button>
          {cameraActive && (
            <button
              onClick={toggleFlash}
              title="تشغيل/إيقاف الفلاش"
              style={{
                background: flashOn ? '#ffc107' : '#555',
                border: 'none', borderRadius: 20, padding: '6px 12px',
                color: flashOn ? '#333' : '#fff', cursor: 'pointer', fontSize: 13,
              }}
            >
              {flashOn ? '🔦 فلاش' : '🔦'}
            </button>
          )}
        </div>
      </div>

      {/* ── Main Container ── */}
      <div style={{ width: '100%', maxWidth: 480, padding: '20px 16px 0', boxSizing: 'border-box' }}>

        {/* ── Status bar ── */}
        {statusMsg && (
          <div
            style={{
              background: statusBg,
              color: '#fff',
              borderRadius: 10,
              padding: '10px 14px',
              marginBottom: 14,
              fontSize: 14,
              lineHeight: 1.5,
            }}
          >
            {statusMsg}
          </div>
        )}

        {/* ── Excel File ── */}
        <SectionLabel text="اختر ملف الأكسيل:" colors={colors} />
        <button
          onClick={() => fileInputRef.current?.click()}
          style={btnStyle(colors.btnPrimary, '#fff')}
        >
          اختر ملف الأكسيل
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls"
          style={{ display: 'none' }}
          onChange={handleFileSelect}
        />
        <div style={inputDisplayStyle(colors)}>
          {excelData ? excelData.fileName : 'لم يتم اختيار ملف'}
        </div>

        {/* ── Subject selector ── */}
        <SectionLabel text="اختر المادة:" colors={colors} />
        <select
          value={selectedSubjectIdx}
          onChange={e => setSelectedSubjectIdx(Number(e.target.value))}
          disabled={!excelData}
          style={{
            ...inputDisplayStyle(colors),
            cursor: excelData ? 'pointer' : 'not-allowed',
            padding: '12px 14px',
            width: '100%',
            appearance: 'none',
          }}
        >
          <option value={-1}>{excelData ? 'اختر المادة...' : 'اختر ملف Excel أولاً'}</option>
          {excelData?.subjects.map((subj, i) => (
            <option key={i} value={i}>
              ({i + 1}) {subj}
            </option>
          ))}
        </select>

        {/* ── Secret code ── */}
        <SectionLabel text="الرقم السري:" colors={colors} />
        <div style={inputDisplayStyle(colors)}>
          {secretCodeDisplay || 'سيظهر هنا الرقم السري'}
        </div>

        {/* ── Stats + Grade Row ── */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 14, alignItems: 'flex-start' }}>
          <div style={{ flex: 1 }}>
            <SectionLabel text="الدرجة:" colors={colors} noMarginBottom />
            <input
              type="text"
              value={gradeInput}
              onChange={e => setGradeInput(e.target.value)}
              placeholder="الدرجة"
              style={{
                ...inputDisplayStyle(colors),
                marginBottom: 0,
                textAlign: 'center',
                fontSize: 22,
                fontWeight: 'bold',
              }}
            />
          </div>
          <div style={{ flex: 1 }}>
            <SectionLabel text="العداد:" colors={colors} noMarginBottom />
            <div
              style={{
                ...inputDisplayStyle(colors),
                marginBottom: 0,
                textAlign: 'center',
                fontSize: 14,
              }}
            >
              {scannedStudents} / {totalStudents}
            </div>
          </div>
        </div>

        {/* ── Start Scan ── */}
        <button
          onClick={cameraActive ? stopCamera : startCamera}
          disabled={!excelData || selectedSubjectIdx < 0}
          style={btnStyle(
            cameraActive ? '#e53935' : colors.btnPrimary,
            '#fff',
            !excelData || selectedSubjectIdx < 0
          )}
        >
          {cameraActive ? '⏹ إيقاف المسح' : 'ابدأ المسح'}
        </button>

        {/* ── Save Grade ── */}
        <button
          onClick={saveGrade}
          disabled={!scanState.studentRow || gradeInput === ''}
          style={btnStyle(
            colors.btnPrimary,
            '#fff',
            !scanState.studentRow || gradeInput === ''
          )}
        >
          حفظ الدرجة
        </button>

        {/* ── Stats button ── */}
        <button
          onClick={() => setShowStats(s => !s)}
          style={btnStyle(colors.btnGold, '#222')}
        >
          {showStats ? 'إخفاء الإحصائيات' : 'عرض الإحصائيات'}
        </button>

        {/* ── Stats panel ── */}
        {showStats && excelData && (
          <div
            style={{
              background: colors.card,
              borderRadius: 12,
              padding: '14px 16px',
              marginBottom: 14,
              border: `1px solid ${colors.border}`,
            }}
          >
            <div style={{ fontSize: 15, marginBottom: 8, fontWeight: 'bold', color: colors.text }}>
              📊 إحصائيات المادة المختارة
            </div>
            <div style={{ fontSize: 14, color: colors.subtext, lineHeight: 2 }}>
              <div>📋 إجمالي الطلاب: <strong style={{ color: colors.text }}>{totalStudents}</strong></div>
              <div>✅ تم إدخال درجاتهم: <strong style={{ color: '#66bb6a' }}>{scannedStudents}</strong></div>
              <div>⏳ المتبقون: <strong style={{ color: '#ffa726' }}>{totalStudents - scannedStudents}</strong></div>
              {selectedSubjectIdx >= 0 && excelData && (
                <div>📚 المادة: <strong style={{ color: colors.text }}>{excelData.subjects[selectedSubjectIdx]}</strong></div>
              )}
            </div>
          </div>
        )}

        {/* ── Camera view ── */}
        <div
          style={{
            background: '#000',
            borderRadius: 12,
            overflow: 'hidden',
            position: 'relative',
            minHeight: 220,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 14,
            border: `2px solid ${cameraActive ? '#4caf50' : colors.border}`,
          }}
        >
          <video
            ref={videoRef}
            playsInline
            muted
            style={{
              width: '100%',
              display: cameraActive ? 'block' : 'none',
              borderRadius: 12,
            }}
          />
          {/* Hidden canvas for processing */}
          <canvas ref={canvasRef} style={{ display: 'none' }} />

          {!cameraActive && (
            <div
              style={{
                color: '#fff',
                textAlign: 'center',
                padding: 30,
                fontSize: 16,
                lineHeight: 1.7,
              }}
            >
              هنا ستظهر شاشة الكاميرا بعد الضغط على زر بدء المسح
            </div>
          )}

          {/* Scan overlay */}
          {cameraActive && (
            <div
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '70%',
                height: '60%',
                border: '2px solid #4caf50',
                borderRadius: 8,
                pointerEvents: 'none',
                boxShadow: '0 0 0 9999px rgba(0,0,0,0.35)',
              }}
            >
              {/* Corner markers */}
              {['topLeft','topRight','bottomLeft','bottomRight'].map(corner => (
                <div
                  key={corner}
                  style={{
                    position: 'absolute',
                    width: 20, height: 20,
                    borderColor: '#4caf50',
                    borderStyle: 'solid',
                    borderWidth: 0,
                    ...(corner === 'topLeft' ? { top: -2, left: -2, borderTopWidth: 4, borderLeftWidth: 4, borderRadius: '4px 0 0 0' } :
                      corner === 'topRight' ? { top: -2, right: -2, borderTopWidth: 4, borderRightWidth: 4, borderRadius: '0 4px 0 0' } :
                      corner === 'bottomLeft' ? { bottom: -2, left: -2, borderBottomWidth: 4, borderLeftWidth: 4, borderRadius: '0 0 0 4px' } :
                      { bottom: -2, right: -2, borderBottomWidth: 4, borderRightWidth: 4, borderRadius: '0 0 4px 0' }),
                  }}
                />
              ))}
            </div>
          )}

          {ocrLoading && (
            <div
              style={{
                position: 'absolute',
                bottom: 10,
                left: '50%',
                transform: 'translateX(-50%)',
                background: '#0008',
                color: '#fff',
                borderRadius: 20,
                padding: '4px 14px',
                fontSize: 12,
              }}
            >
              ⏳ جارٍ المعالجة...
            </div>
          )}
        </div>

        {/* ── Note ── */}
        <div
          style={{
            background: colors.card,
            borderRadius: 10,
            padding: '10px 14px',
            fontSize: 12,
            color: colors.subtext,
            lineHeight: 1.7,
            border: `1px solid ${colors.border}`,
          }}
        >
          <strong style={{ color: colors.text }}>ملاحظة:</strong>
          <ul style={{ margin: '6px 0 0 0', paddingRight: 18 }}>
            <li>تأكد من أن ملف الأكسيل في مجلد <strong>التنزيلات / درجات الطلاب</strong></li>
            <li>كود المادة مطبوع بالورقة (1–15) ويتطابق مع ترتيب المادة</li>
            <li>رمز QR يحمل الرقم السري للطالب (عمود D)</li>
            <li>الدرجة مكتوبة بخط اليد (أرقام عربية أو هندية)</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════
// Sub-components
// ══════════════════════════════════════════════
function SectionLabel({ text, colors, noMarginBottom }: { text: string; colors: Record<string,string>; noMarginBottom?: boolean }) {
  return (
    <div
      style={{
        color: colors.subtext,
        fontSize: 14,
        fontWeight: 'bold',
        marginBottom: noMarginBottom ? 4 : 4,
        marginTop: 4,
        textAlign: 'right',
      }}
    >
      {text}
    </div>
  )
}

function inputDisplayStyle(colors: Record<string,string>): React.CSSProperties {
  return {
    background: colors.input,
    color: colors.text,
    border: `1px solid ${colors.border}`,
    borderRadius: 8,
    padding: '12px 14px',
    fontSize: 15,
    width: '100%',
    boxSizing: 'border-box',
    marginBottom: 12,
    textAlign: 'right',
    direction: 'rtl',
  }
}

function btnStyle(bg: string, color: string, disabled?: boolean): React.CSSProperties {
  return {
    background: disabled ? '#555' : bg,
    color,
    border: 'none',
    borderRadius: 30,
    padding: '14px 0',
    fontSize: 16,
    fontWeight: 'bold',
    width: '100%',
    cursor: disabled ? 'not-allowed' : 'pointer',
    marginBottom: 12,
    transition: 'background 0.2s',
    opacity: disabled ? 0.6 : 1,
    fontFamily: 'Cairo, Tajawal, Arial, sans-serif',
  }
}
